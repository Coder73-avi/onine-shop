import axios from "axios";
import Cookies from "js-cookie";

const url = process.env.URL || "http://localhost:4001";
const auth = Cookies.get("auth");
const instance = axios.create({
  baseURL: url,
  withCredentials: true,
  headers: {
    Authorization: "Bearer 1234",
  },
});

export default instance;
