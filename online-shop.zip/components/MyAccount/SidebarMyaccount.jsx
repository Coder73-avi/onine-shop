import React from "react";

const SidebarMyaccount = () => {
  return <div>SidebarMyaccount</div>;
};

export default SidebarMyaccount;
