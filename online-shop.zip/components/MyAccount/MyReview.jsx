import React from "react";

const MyReview = () => {
  return <div>MyReview</div>;
};

export default MyReview;
