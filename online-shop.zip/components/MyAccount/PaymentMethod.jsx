import React from "react";

const PaymentMethod = () => {
  return (
    <>
      <h1 className="text-lg font-extrabold my-2 text-gray-800">
        My Payment Method
      </h1>
      <hr className="mb-4" />
    </>
  );
};

export default PaymentMethod;
