import React from "react";
import css from "./quickview.module.css";

const QuickView = () => {
  return <div>Quick View</div>;
};

export default QuickView;
